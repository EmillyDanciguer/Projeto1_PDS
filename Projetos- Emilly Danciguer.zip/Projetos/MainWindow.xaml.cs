﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Projetos
{
	/// <summary>
	/// Interação lógica para MainWindow.xam
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btLogar_Click(object sender, RoutedEventArgs e)
		{
			string usuario = txtUser.Text;
			string senha = pwSenha.Password.ToString();

			if (usuario == "emilly" && senha == "123e")
			{
				MessageBox.Show("Logado!");
				
				txtUser.Clear();
				pwSenha.Clear();
				Calculadora calculadora = new Calculadora();
		
				calculadora.ShowDialog();
				this.Close();
			}
			else
			{
				MessageBox.Show("Usuário(a) ou senha inserido incorretamente!", "ERRO", MessageBoxButton.OK, MessageBoxImage.Error);
				txtUser.Clear();
				pwSenha.Clear();
				txtUser.Focus();
			}
		}
	}
}
