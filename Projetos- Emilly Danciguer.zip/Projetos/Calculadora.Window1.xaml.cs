﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projetos
{
	/// <summary>
	/// Lógica interna para Calculadora.xaml
	/// </summary>
	public partial class Calculadora : Window
	{
		public Calculadora()
		{
			InitializeComponent();
		}

		private void btSomar_Click(object sender, RoutedEventArgs e)
		{
			double n1 = Convert.ToDouble(txtN1.Text);
			double n2 = Convert.ToDouble(txtN2.Text);

			double resultado = n1 + n2;
			txtRes.Text = Convert.ToString(resultado);
		}

		private void btSubtrair_Click(object sender, RoutedEventArgs e)
		{
			double n1 = Convert.ToDouble(txtN1.Text);
			double n2 = Convert.ToDouble(txtN2.Text);

			double resultado = n1 - n2;
			txtRes.Text = Convert.ToString(resultado);
		}

		private void btDividir_Click(object sender, RoutedEventArgs e)
		{
			double n1 = Convert.ToDouble(txtN1.Text);
			double n2 = Convert.ToDouble(txtN2.Text);

			double resultado = n1 / n2;
			txtRes.Text = Convert.ToString(resultado);
		}

		private void btMultiplicar_Click(object sender, RoutedEventArgs e)
		{
			double n1 = Convert.ToDouble(txtN1.Text);
			double n2 = Convert.ToDouble(txtN2.Text);

			double resultado = n1 * n2;
			txtRes.Text = Convert.ToString(resultado);
		}

		private void btLimpar_Click(object sender, RoutedEventArgs e)
		{
			txtN1.Clear();
			txtN2.Clear();
			txtRes.Clear();
			txtN1.Focus();
		}
	}
}
